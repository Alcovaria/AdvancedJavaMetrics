function foo(arg1, arg2) {
    alert('foo');
    function bar(arg3, arg4) {
        alert('bar');
    }
}

function buz(arg1, arg2) {
    alert('bar');
}

for (var i = 0; i < 10; i++) {
}

if (2 == 2){
    alert('nil')
} else {
    alert('nel')
}

var a = 1;

var car = {type:"Fiat", model:"500", color:"white"};

var car2 = {type:"Fiat", model:"600", color:"black"};