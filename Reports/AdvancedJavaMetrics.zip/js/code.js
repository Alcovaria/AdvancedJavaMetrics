function fun1(arg1, arg2){
	alert('Me is function1');
	} 
function fun2(arg1, arg2){
	alert('Me is function2');
	}
function fun3(arg1, arg2){
	alert('Me is function3');
	}